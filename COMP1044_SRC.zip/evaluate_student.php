<?php
/**
 * Evaluate Student - Assessment Entry
 * COMP1044 Assignment
 */

require_once 'session.php';
require_once 'db_connect.php';

// Ensure only assessors can access this page
if (!is_assessor()) {
    set_error_message("Access denied. Assessor privileges required.");
    header("Location: login.php");
    exit();
}

$assessor_id = $_SESSION['user_id'];
$internship_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($internship_id === 0) {
    set_error_message("Invalid internship record.");
    header("Location: assessor_dashboard.php");
    exit();
}

// 1. Verify this student is assigned to THIS assessor
$sql = "SELECT i.*, s.student_id, s.student_name 
        FROM internships i
        JOIN students s ON i.student_id = s.id
        WHERE i.internship_id = ? AND i.assessor_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $internship_id, $assessor_id);
mysqli_stmt_execute($stmt);
$internship = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$internship) {
    set_error_message("You do not have permission to evaluate this student.");
    header("Location: assessor_dashboard.php");
    exit();
}

// 2. Check if assessment already exists (Unique constraint in DB)
$check_sql = "SELECT assessment_id FROM assessments WHERE internship_id = ?";
$check_stmt = mysqli_prepare($conn, $check_sql);
mysqli_stmt_bind_param($check_stmt, "i", $internship_id);
mysqli_stmt_execute($check_stmt);
if (mysqli_num_rows(mysqli_stmt_get_result($check_stmt)) > 0) {
    set_error_message("Assessment already submitted for this student.");
    header("Location: view_assessment.php?id=" . $internship_id);
    exit();
}

// 3. Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect scores
    $scores = [
        'tasks' => floatval($_POST['undertaking_tasks']),
        'health' => floatval($_POST['health_safety']),
        'it' => floatval($_POST['connectivity_knowledge']),
        'report' => floatval($_POST['report_presentation']),
        'lang' => floatval($_POST['clarity_language']),
        'learn' => floatval($_POST['lifelong_learning']),
        'proj' => floatval($_POST['project_management']),
        'time' => floatval($_POST['time_management'])
    ];

    $general_feedback = sanitize_input($conn, $_POST['general_feedback']);

    // INSERT query using exact columns from COMP1044_Database.sql
    $insert_sql = "INSERT INTO assessments (
        internship_id, undertaking_tasks, health_safety, connectivity_knowledge, 
        report_presentation, clarity_language, lifelong_learning, 
        project_management, time_management, general_feedback, assessed_by
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $insert_stmt = mysqli_prepare($conn, $insert_sql);
    mysqli_stmt_bind_param($insert_stmt, "iddddddddsi", 
        $internship_id, 
        $scores['tasks'], $scores['health'], $scores['it'], 
        $scores['report'], $scores['lang'], $scores['learn'], 
        $scores['proj'], $scores['time'], 
        $general_feedback, 
        $assessor_id
    );
    
    if (mysqli_stmt_execute($insert_stmt)) {
        set_success_message("Assessment successfully saved for " . $internship['student_name']);
        header("Location: assessor_dashboard.php");
        exit();
    } else {
        set_error_message("Error saving assessment: " . mysqli_error($conn));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Evaluate Student</title>
    <link rel="stylesheet" href="style.css"> <style>
        .form-container { max-width: 800px; margin: 20px auto; padding: 20px; background: #fff; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .grid-row { display: grid; grid-template-columns: 2fr 1fr; gap: 15px; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px solid #eee; }
        .score-input { width: 80px; padding: 5px; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 4px; }
        .alert-danger { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Assessment Form: <?php echo htmlspecialchars($internship['student_name']); ?></h2>
        <p><strong>Student ID:</strong> <?php echo htmlspecialchars($internship['student_id']); ?></p>
        <hr>

        <?php if ($err = get_error_message()): ?>
            <div class="alert alert-danger"><?php echo $err; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="grid-row">
                <label>1. Undertaking Tasks / Work Quality (10%)</label>
                <input type="number" name="undertaking_tasks" step="0.01" min="0" max="100" required class="score-input">
            </div>
            <div class="grid-row">
                <label>2. Health, Safety & Professionalism (10%)</label>
                <input type="number" name="health_safety" step="0.01" min="0" max="100" required class="score-input">
            </div>
            <div class="grid-row">
                <label>3. Connectivity & IT Knowledge (10%)</label>
                <input type="number" name="connectivity_knowledge" step="0.01" min="0" max="100" required class="score-input">
            </div>
            <div class="grid-row">
                <label>4. Report Quality & Presentation (15%)</label>
                <input type="number" name="report_presentation" step="0.01" min="0" max="100" required class="score-input">
            </div>
            <div class="grid-row">
                <label>5. Clarity of Language (10%)</label>
                <input type="number" name="clarity_language" step="0.01" min="0" max="100" required class="score-input">
            </div>
            <div class="grid-row">
                <label>6. Lifelong Learning & Adaptability (15%)</label>
                <input type="number" name="lifelong_learning" step="0.01" min="0" max="100" required class="score-input">
            </div>
            <div class="grid-row">
                <label>7. Project Management Skills (15%)</label>
                <input type="number" name="project_management" step="0.01" min="0" max="100" required class="score-input">
            </div>
            <div class="grid-row">
                <label>8. Time Management (15%)</label>
                <input type="number" name="time_management" step="0.01" min="0" max="100" required class="score-input">
            </div>

            <div style="margin-top: 20px;">
                <label><strong>General Feedback / Comments:</strong></label><br>
                <textarea name="general_feedback" rows="4" style="width: 100%; margin-top: 10px;" placeholder="Enter overall performance comments..."></textarea>
            </div>

            <div style="margin-top: 20px; display: flex; gap: 10px;">
                <button type="submit" class="btn-primary">Submit Evaluation</button>
                <a href="assessor_dashboard.php" class="btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>