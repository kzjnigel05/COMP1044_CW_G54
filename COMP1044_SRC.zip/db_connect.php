<?php
/**
 * Database Connection Configuration
 * Internship Result Management System
 * COMP1044 Assignment
 */

// Database configuration constants
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');
define('DB_NAME', 'comp1044_database');

// Create connection
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if ($conn === false) {
    die("ERROR: Could not connect to database. " . mysqli_connect_error());
}

// Set charset to utf8mb4 for proper character encoding
mysqli_set_charset($conn, "utf8mb4");

/**
 * Function to sanitize user input
 * @param object $conn - Database connection
 * @param string $data - Data to sanitize
 * @return string - Sanitized data
 */
function sanitize_input($conn, $data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $data = mysqli_real_escape_string($conn, $data);
    return $data;
}

/**
 * Function to validate email format
 * @param string $email - Email to validate
 * @return bool - True if valid, false otherwise
 */
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Function to log activity (optional for tracking)
 * @param object $conn - Database connection
 * @param int $user_id - User performing the action
 * @param string $action - Action performed
 * @param string $details - Additional details
 */
function log_activity($conn, $user_id, $action, $details = '') {
    $sql = "INSERT INTO activity_logs (user_id, action, details, created_at) 
            VALUES (?, ?, ?, NOW())";
    
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "iss", $user_id, $action, $details);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}
?>
