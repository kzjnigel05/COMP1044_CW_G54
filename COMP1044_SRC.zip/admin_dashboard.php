<?php
/**
 * Admin Dashboard
 * Main dashboard for administrators with system statistics
 * COMP1044 Assignment
 */

require_once 'session.php';
require_once 'db_connect.php';

// Require admin privileges
require_admin();

// Fetch statistics
$stats = array(
    'total_students' => 0,
    'total_assessors' => 0,
    'total_internships' => 0,
    'pending_assessments' => 0,
    'completed_assessments' => 0,
    'average_score' => 0
);

// Get total students
$sql = "SELECT COUNT(*) as count FROM students WHERE is_active = 1";
$result = mysqli_query($conn, $sql);
if ($row = mysqli_fetch_assoc($result)) {
    $stats['total_students'] = $row['count'];
}

// Get total assessors
$sql = "SELECT COUNT(*) as count FROM users WHERE role = 'Assessor' AND is_active = 1";
$result = mysqli_query($conn, $sql);
if ($row = mysqli_fetch_assoc($result)) {
    $stats['total_assessors'] = $row['count'];
}

// Get total internships
$sql = "SELECT COUNT(*) as count FROM internships";
$result = mysqli_query($conn, $sql);
if ($row = mysqli_fetch_assoc($result)) {
    $stats['total_internships'] = $row['count'];
}

// Get pending assessments
$sql = "SELECT COUNT(*) as count FROM internships i 
        LEFT JOIN assessments a ON i.internship_id = a.internship_id 
        WHERE a.assessment_id IS NULL";
$result = mysqli_query($conn, $sql);
if ($row = mysqli_fetch_assoc($result)) {
    $stats['pending_assessments'] = $row['count'];
}

// Get completed assessments
$sql = "SELECT COUNT(*) as count FROM assessments";
$result = mysqli_query($conn, $sql);
if ($row = mysqli_fetch_assoc($result)) {
    $stats['completed_assessments'] = $row['count'];
}

// Get average score
$sql = "SELECT AVG(final_score) as avg_score FROM assessments";
$result = mysqli_query($conn, $sql);
if ($row = mysqli_fetch_assoc($result)) {
    $stats['average_score'] = round($row['avg_score'], 2);
}

// Get recent activities
$recent_activities = array();
$sql = "SELECT al.*, u.full_name 
        FROM activity_logs al 
        LEFT JOIN users u ON al.user_id = u.user_id 
        ORDER BY al.created_at DESC 
        LIMIT 10";
$result = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($result)) {
    $recent_activities[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Internship Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .navbar h1 {
            font-size: 24px;
        }
        
        .navbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-avatar {
            width: 35px;
            height: 35px;
            background: white;
            color: #667eea;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        
        .btn-logout {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 1px solid white;
            padding: 8px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s;
        }
        
        .btn-logout:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 30px;
        }
        
        .welcome-section {
            background: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .welcome-section h2 {
            color: #333;
            margin-bottom: 10px;
        }
        
        .welcome-section p {
            color: #666;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        
        .stat-card h3 {
            color: #666;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 10px;
            text-transform: uppercase;
        }
        
        .stat-value {
            font-size: 36px;
            font-weight: bold;
            color: #667eea;
        }
        
        .stat-card.success .stat-value {
            color: #4caf50;
        }
        
        .stat-card.warning .stat-value {
            color: #ff9800;
        }
        
        .stat-card.info .stat-value {
            color: #2196f3;
        }
        
        .quick-actions {
            background: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .quick-actions h3 {
            margin-bottom: 20px;
            color: #333;
        }
        
        .action-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .action-btn {
            display: block;
            padding: 15px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            text-align: center;
            font-weight: 500;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        
        .recent-activity {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .recent-activity h3 {
            margin-bottom: 20px;
            color: #333;
        }
        
        .activity-list {
            list-style: none;
        }
        
        .activity-item {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-info {
            flex: 1;
        }
        
        .activity-user {
            font-weight: 600;
            color: #333;
        }
        
        .activity-action {
            color: #666;
            font-size: 14px;
        }
        
        .activity-time {
            color: #999;
            font-size: 12px;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background-color: #e8f5e9;
            border-left: 4px solid #4caf50;
            color: #2e7d32;
        }
        
        .alert-error {
            background-color: #fee;
            border-left: 4px solid #f44336;
            color: #c33;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-content">
            <h1>Admin Dashboard</h1>
            <div class="navbar-right">
                <div class="user-info">
                    <div class="user-avatar">
                        <?php echo strtoupper(substr(get_user_name(), 0, 1)); ?>
                    </div>
                    <span><?php echo htmlspecialchars(get_user_name()); ?></span>
                </div>
                <a href="logout.php" class="btn-logout">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <?php 
        $success_msg = get_success_message();
        if (!empty($success_msg)): 
        ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success_msg); ?>
            </div>
        <?php endif; ?>
        
        <?php 
        $error_msg = get_error_message();
        if (!empty($error_msg)): 
        ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($error_msg); ?>
            </div>
        <?php endif; ?>
        
        <div class="welcome-section">
            <h2>Welcome, <?php echo htmlspecialchars(get_user_name()); ?>!</h2>
            <p>Here's an overview of the internship management system.</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Students</h3>
                <div class="stat-value"><?php echo $stats['total_students']; ?></div>
            </div>
            
            <div class="stat-card info">
                <h3>Total Assessors</h3>
                <div class="stat-value"><?php echo $stats['total_assessors']; ?></div>
            </div>
            
            <div class="stat-card success">
                <h3>Completed Assessments</h3>
                <div class="stat-value"><?php echo $stats['completed_assessments']; ?></div>
            </div>
            
            <div class="stat-card warning">
                <h3>Pending Assessments</h3>
                <div class="stat-value"><?php echo $stats['pending_assessments']; ?></div>
            </div>
            
            <div class="stat-card">
                <h3>Total Internships</h3>
                <div class="stat-value"><?php echo $stats['total_internships']; ?></div>
            </div>
            
            <div class="stat-card success">
                <h3>Average Score</h3>
                <div class="stat-value"><?php echo $stats['average_score'] ?: 'N/A'; ?></div>
            </div>
        </div>
        
        <div class="quick-actions">
            <h3>Quick Actions</h3>
            <div class="action-grid">
                <a href="manage_students.php" class="action-btn">Manage Students</a>
                <a href="manage_assessors.php" class="action-btn">Manage Assessors</a>
                <a href="manage_internships.php" class="action-btn">Manage Internships</a>
                <a href="view_results.php" class="action-btn">View All Results</a>
            </div>
        </div>
        
        <div class="recent-activity">
            <h3>Recent Activity</h3>
            <?php if (count($recent_activities) > 0): ?>
                <ul class="activity-list">
                    <?php foreach ($recent_activities as $activity): ?>
                        <li class="activity-item">
                            <div class="activity-info">
                                <div class="activity-user">
                                    <?php echo htmlspecialchars($activity['full_name'] ?: 'Unknown User'); ?>
                                </div>
                                <div class="activity-action">
                                    <?php echo htmlspecialchars($activity['action']); ?>
                                    <?php if (!empty($activity['details'])): ?>
                                        - <?php echo htmlspecialchars($activity['details']); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="activity-time">
                                <?php echo date('M d, Y H:i', strtotime($activity['created_at'])); ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p style="color: #666; padding: 20px; text-align: center;">No recent activity</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
