<?php
/**
 * View Results
 * Admin/Assessor interface for viewing internship assessment results
 * COMP1044 Assignment
 */

require_once 'session.php';
require_once 'db_connect.php';

// Require login (both Admin and Assessor can view results)
require_login();

// Get filter parameters
$search = isset($_GET['search']) ? sanitize_input($conn, $_GET['search']) : '';
$filter_assessor = isset($_GET['assessor']) ? intval($_GET['assessor']) : 0;
$filter_grade = isset($_GET['grade']) ? sanitize_input($conn, $_GET['grade']) : '';
$sort_by = isset($_GET['sort']) ? sanitize_input($conn, $_GET['sort']) : 'student_name';
$sort_order = isset($_GET['order']) && $_GET['order'] === 'desc' ? 'DESC' : 'ASC';

// Build query based on user role and filters
$results = array();

// Base query - different for Admin vs Assessor
if (is_admin()) {
    // Admin can see all results
    $base_sql = "SELECT 
        s.student_id,
        s.student_name,
        s.programme,
        i.company_name,
        i.internship_start_date,
        i.internship_end_date,
        u.full_name AS assessor_name,
        u.user_id AS assessor_id,
        a.*,
        CASE 
            WHEN a.final_score >= 80 THEN 'Excellent'
            WHEN a.final_score >= 70 THEN 'Good'
            WHEN a.final_score >= 60 THEN 'Satisfactory'
            WHEN a.final_score >= 50 THEN 'Pass'
            ELSE 'Fail'
        END AS grade
    FROM students s
    INNER JOIN internships i ON s.id = i.student_id
    INNER JOIN assessments a ON i.internship_id = a.internship_id
    INNER JOIN users u ON i.assessor_id = u.user_id
    WHERE s.is_active = 1";
} else {
    // Assessor can only see their own assessments
    $base_sql = "SELECT 
        s.student_id,
        s.student_name,
        s.programme,
        i.company_name,
        i.internship_start_date,
        i.internship_end_date,
        u.full_name AS assessor_name,
        u.user_id AS assessor_id,
        a.*,
        CASE 
            WHEN a.final_score >= 80 THEN 'Excellent'
            WHEN a.final_score >= 70 THEN 'Good'
            WHEN a.final_score >= 60 THEN 'Satisfactory'
            WHEN a.final_score >= 50 THEN 'Pass'
            ELSE 'Fail'
        END AS grade
    FROM students s
    INNER JOIN internships i ON s.id = i.student_id
    INNER JOIN assessments a ON i.internship_id = a.internship_id
    INNER JOIN users u ON i.assessor_id = u.user_id
    WHERE s.is_active = 1 AND i.assessor_id = " . $_SESSION['user_id'];
}

// Add filters
$conditions = array();
$params = array();
$types = '';

if (!empty($search)) {
    $conditions[] = "(s.student_id LIKE ? OR s.student_name LIKE ? OR s.programme LIKE ? OR i.company_name LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $types .= 'ssss';
}

if ($filter_assessor > 0 && is_admin()) {
    $conditions[] = "i.assessor_id = ?";
    $params[] = $filter_assessor;
    $types .= 'i';
}

if (!empty($filter_grade)) {
    switch ($filter_grade) {
        case 'Excellent':
            $conditions[] = "a.final_score >= 80";
            break;
        case 'Good':
            $conditions[] = "a.final_score >= 70 AND a.final_score < 80";
            break;
        case 'Satisfactory':
            $conditions[] = "a.final_score >= 60 AND a.final_score < 70";
            break;
        case 'Pass':
            $conditions[] = "a.final_score >= 50 AND a.final_score < 60";
            break;
        case 'Fail':
            $conditions[] = "a.final_score < 50";
            break;
    }
}

if (!empty($conditions)) {
    $base_sql .= " AND " . implode(" AND ", $conditions);
}

// Add sorting
$valid_sort_columns = array(
    'student_name' => 's.student_name',
    'student_id' => 's.student_id',
    'programme' => 's.programme',
    'company' => 'i.company_name',
    'assessor' => 'u.full_name',
    'score' => 'a.final_score',
    'assessed_at' => 'a.assessed_at'
);

$sort_column = isset($valid_sort_columns[$sort_by]) ? $valid_sort_columns[$sort_by] : 's.student_name';
$base_sql .= " ORDER BY $sort_column $sort_order";

// Execute query
if (!empty($params)) {
    $stmt = mysqli_prepare($conn, $base_sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
    }
} else {
    $result = mysqli_query($conn, $base_sql);
}

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $results[] = $row;
    }
}

// Get all assessors for filter dropdown (Admin only)
$assessors = array();
if (is_admin()) {
    $assessor_sql = "SELECT user_id, full_name FROM users WHERE role = 'Assessor' AND is_active = 1 ORDER BY full_name";
    $assessor_result = mysqli_query($conn, $assessor_sql);
    while ($row = mysqli_fetch_assoc($assessor_result)) {
        $assessors[] = $row;
    }
}

// Calculate statistics
$total_results = count($results);
$average_score = 0;
$grade_distribution = array(
    'Excellent' => 0,
    'Good' => 0,
    'Satisfactory' => 0,
    'Pass' => 0,
    'Fail' => 0
);

if ($total_results > 0) {
    $total_score = 0;
    foreach ($results as $result) {
        $total_score += $result['final_score'];
        $grade_distribution[$result['grade']]++;
    }
    $average_score = round($total_score / $total_results, 2);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Results - Internship Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .navbar h1 {
            font-size: 24px;
        }
        
        .btn-back {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 1px solid white;
            padding: 8px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s;
        }
        
        .btn-back:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 30px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .stat-card h3 {
            color: #666;
            font-size: 13px;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        
        .stat-value {
            font-size: 28px;
            font-weight: bold;
            color: #667eea;
        }
        
        .stat-card.excellent .stat-value { color: #4caf50; }
        .stat-card.good .stat-value { color: #2196f3; }
        .stat-card.satisfactory .stat-value { color: #ff9800; }
        .stat-card.fail .stat-value { color: #f44336; }
        
        .filters-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .filters-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
        }
        
        .filter-group label {
            font-size: 13px;
            color: #666;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .filter-group input,
        .filter-group select {
            padding: 10px 12px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .filter-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }
        
        .btn-primary, .btn-secondary {
            padding: 10px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
            transition: transform 0.2s;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
            background: #e0e0e0;
            color: #666;
        }
        
        .btn-secondary:hover {
            background: #d0d0d0;
        }
        
        .table-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }
        
        thead {
            background: #f8f9fa;
        }
        
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #333;
            border-bottom: 2px solid #e0e0e0;
            cursor: pointer;
            user-select: none;
        }
        
        th:hover {
            background: #e9ecef;
        }
        
        th.sortable::after {
            content: ' ⇅';
            color: #999;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            color: #666;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        .badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-excellent {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .badge-good {
            background: #e3f2fd;
            color: #1565c0;
        }
        
        .badge-satisfactory {
            background: #fff3e0;
            color: #e65100;
        }
        
        .badge-pass {
            background: #fff9c4;
            color: #f57f17;
        }
        
        .badge-fail {
            background: #ffebee;
            color: #c62828;
        }
        
        .btn-view {
            padding: 6px 15px;
            background: #2196f3;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-view:hover {
            background: #1976d2;
        }
        
        .no-results {
            padding: 60px;
            text-align: center;
            color: #999;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .alert-info {
            background-color: #e3f2fd;
            border-left: 4px solid #2196f3;
            color: #1565c0;
        }
        
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            overflow-y: auto;
        }
        
        .modal-content {
            background-color: white;
            margin: 30px auto;
            padding: 0;
            border-radius: 10px;
            width: 90%;
            max-width: 900px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .modal-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 30px;
            border-radius: 10px 10px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-header h2 {
            margin: 0;
        }
        
        .close {
            color: white;
            font-size: 32px;
            font-weight: bold;
            cursor: pointer;
            line-height: 1;
        }
        
        .close:hover {
            opacity: 0.8;
        }
        
        .modal-body {
            padding: 30px;
        }
        
        .detail-section {
            margin-bottom: 25px;
        }
        
        .detail-section h3 {
            color: #333;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e0e0e0;
        }
        
        .detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .detail-item {
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        
        .detail-label {
            font-size: 12px;
            color: #666;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        
        .detail-value {
            font-size: 15px;
            color: #333;
            font-weight: 500;
        }
        
        .score-breakdown {
            display: grid;
            grid-template-columns: 1fr 100px 100px;
            gap: 10px;
            margin-bottom: 10px;
        }
        
        .score-breakdown-header {
            font-weight: 600;
            color: #333;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        
        .score-item {
            padding: 10px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .score-name {
            color: #666;
        }
        
        .score-value {
            text-align: center;
            font-weight: 600;
            color: #667eea;
        }
        
        .score-weighted {
            text-align: center;
            color: #999;
        }
        
        .final-score {
            font-size: 48px;
            font-weight: bold;
            color: #667eea;
            text-align: center;
            margin: 20px 0;
        }
        
        .comments-section {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-top: 10px;
        }
        
        .comment-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }
        
        .comment-text {
            color: #666;
            line-height: 1.6;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-content">
            <h1>View Assessment Results</h1>
            <a href="<?php echo get_dashboard_url(); ?>" class="btn-back">← Back to Dashboard</a>
        </div>
    </nav>
    
    <div class="container">
        <?php if (is_assessor()): ?>
            <div class="alert alert-info">
                You are viewing results for students assigned to you.
            </div>
        <?php endif; ?>
        
        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Results</h3>
                <div class="stat-value"><?php echo $total_results; ?></div>
            </div>
            
            <div class="stat-card">
                <h3>Average Score</h3>
                <div class="stat-value"><?php echo $average_score; ?>%</div>
            </div>
            
            <div class="stat-card excellent">
                <h3>Excellent</h3>
                <div class="stat-value"><?php echo $grade_distribution['Excellent']; ?></div>
            </div>
            
            <div class="stat-card good">
                <h3>Good</h3>
                <div class="stat-value"><?php echo $grade_distribution['Good']; ?></div>
            </div>
            
            <div class="stat-card satisfactory">
                <h3>Satisfactory</h3>
                <div class="stat-value"><?php echo $grade_distribution['Satisfactory']; ?></div>
            </div>
            
            <div class="stat-card fail">
                <h3>Pass</h3>
                <div class="stat-value"><?php echo $grade_distribution['Pass']; ?></div>
            </div>
        </div>
        
        <!-- Filters -->
        <div class="filters-section">
            <form method="GET" action="">
                <div class="filters-grid">
                    <div class="filter-group">
                        <label>Search</label>
                        <input type="text" name="search" placeholder="Student ID, name, programme, or company..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    
                    <?php if (is_admin()): ?>
                    <div class="filter-group">
                        <label>Assessor</label>
                        <select name="assessor">
                            <option value="0">All Assessors</option>
                            <?php foreach ($assessors as $assessor): ?>
                                <option value="<?php echo $assessor['user_id']; ?>" 
                                        <?php echo $filter_assessor == $assessor['user_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($assessor['full_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    
                    <div class="filter-group">
                        <label>Grade</label>
                        <select name="grade">
                            <option value="">All Grades</option>
                            <option value="Excellent" <?php echo $filter_grade === 'Excellent' ? 'selected' : ''; ?>>Excellent (≥80)</option>
                            <option value="Good" <?php echo $filter_grade === 'Good' ? 'selected' : ''; ?>>Good (70-79)</option>
                            <option value="Satisfactory" <?php echo $filter_grade === 'Satisfactory' ? 'selected' : ''; ?>>Satisfactory (60-69)</option>
                            <option value="Pass" <?php echo $filter_grade === 'Pass' ? 'selected' : ''; ?>>Pass (50-59)</option>
                            <option value="Fail" <?php echo $filter_grade === 'Fail' ? 'selected' : ''; ?>>Fail (<50)</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Sort By</label>
                        <select name="sort">
                            <option value="student_name" <?php echo $sort_by === 'student_name' ? 'selected' : ''; ?>>Student Name</option>
                            <option value="student_id" <?php echo $sort_by === 'student_id' ? 'selected' : ''; ?>>Student ID</option>
                            <option value="programme" <?php echo $sort_by === 'programme' ? 'selected' : ''; ?>>Programme</option>
                            <option value="score" <?php echo $sort_by === 'score' ? 'selected' : ''; ?>>Score</option>
                            <option value="assessed_at" <?php echo $sort_by === 'assessed_at' ? 'selected' : ''; ?>>Assessment Date</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Order</label>
                        <select name="order">
                            <option value="asc" <?php echo $sort_order === 'ASC' ? 'selected' : ''; ?>>Ascending</option>
                            <option value="desc" <?php echo $sort_order === 'DESC' ? 'selected' : ''; ?>>Descending</option>
                        </select>
                    </div>
                </div>
                
                <div class="filter-actions">
                    <a href="view_results.php" class="btn-secondary">Clear Filters</a>
                    <button type="submit" class="btn-primary">Apply Filters</button>
                </div>
            </form>
        </div>
        
        <!-- Results Table -->
        <div class="table-container">
            <?php if (count($results) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Programme</th>
                            <th>Company</th>
                            <?php if (is_admin()): ?>
                            <th>Assessor</th>
                            <?php endif; ?>
                            <th>Final Score</th>
                            <th>Grade</th>
                            <th>Assessed Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results as $result): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($result['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($result['student_name']); ?></td>
                                <td><?php echo htmlspecialchars($result['programme']); ?></td>
                                <td><?php echo htmlspecialchars($result['company_name']); ?></td>
                                <?php if (is_admin()): ?>
                                <td><?php echo htmlspecialchars($result['assessor_name']); ?></td>
                                <?php endif; ?>
                                <td><strong><?php echo number_format($result['final_score'], 2); ?>%</strong></td>
                                <td>
                                    <span class="badge badge-<?php echo strtolower($result['grade']); ?>">
                                        <?php echo $result['grade']; ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($result['assessed_at'])); ?></td>
                                <td>
                                    <button class="btn-view" onclick='viewDetails(<?php echo json_encode($result); ?>)'>
                                        View Details
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-results">
                    <?php if (!empty($search) || $filter_assessor > 0 || !empty($filter_grade)): ?>
                        No results found matching your filters.
                    <?php else: ?>
                        No assessment results available yet.
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Details Modal -->
    <div id="detailsModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Assessment Details</h2>
                <span class="close" onclick="closeModal()">&times;</span>
            </div>
            <div class="modal-body">
                <!-- Student Information -->
                <div class="detail-section">
                    <h3>Student Information</h3>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <div class="detail-label">Student ID</div>
                            <div class="detail-value" id="modal_student_id"></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Student Name</div>
                            <div class="detail-value" id="modal_student_name"></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Programme</div>
                            <div class="detail-value" id="modal_programme"></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Company</div>
                            <div class="detail-value" id="modal_company"></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Internship Period</div>
                            <div class="detail-value" id="modal_period"></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Assessor</div>
                            <div class="detail-value" id="modal_assessor"></div>
                        </div>
                    </div>
                </div>
                
                <!-- Final Score -->
                <div class="detail-section">
                    <h3>Final Score</h3>
                    <div class="final-score" id="modal_final_score"></div>
                    <div style="text-align: center;">
                        <span class="badge" id="modal_grade_badge"></span>
                    </div>
                </div>
                
                <!-- Score Breakdown -->
                <div class="detail-section">
                    <h3>Score Breakdown</h3>
                    <div class="score-breakdown">
                        <div class="score-breakdown-header">Assessment Component</div>
                        <div class="score-breakdown-header">Score</div>
                        <div class="score-breakdown-header">Weight</div>
                    </div>
                    <div id="score_breakdown_content"></div>
                </div>
                
                <!-- Comments -->
                <div class="detail-section">
                    <h3>Assessor Comments</h3>
                    <div id="comments_content"></div>
                    
                    <div class="comments-section" style="margin-top: 20px;">
                        <div class="comment-label">General Feedback</div>
                        <div class="comment-text" id="modal_general_feedback"></div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <div class="detail-item">
                        <div class="detail-label">Assessment Date</div>
                        <div class="detail-value" id="modal_assessed_at"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function viewDetails(result) {
            // Student information
            document.getElementById('modal_student_id').textContent = result.student_id;
            document.getElementById('modal_student_name').textContent = result.student_name;
            document.getElementById('modal_programme').textContent = result.programme;
            document.getElementById('modal_company').textContent = result.company_name;
            
            // Internship period
            let period = '-';
            if (result.internship_start_date && result.internship_end_date) {
                const startDate = new Date(result.internship_start_date);
                const endDate = new Date(result.internship_end_date);
                period = startDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) +
                        ' - ' + endDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
            }
            document.getElementById('modal_period').textContent = period;
            document.getElementById('modal_assessor').textContent = result.assessor_name;
            
            // Final score
            document.getElementById('modal_final_score').textContent = parseFloat(result.final_score).toFixed(2) + '%';
            
            // Grade badge
            const gradeBadge = document.getElementById('modal_grade_badge');
            gradeBadge.textContent = result.grade;
            gradeBadge.className = 'badge badge-' + result.grade.toLowerCase();
            
            // Score breakdown
            const components = [
                { name: 'Undertaking Tasks/Projects', score: result.undertaking_tasks, weight: '10%', comment: result.comments_undertaking },
                { name: 'Health and Safety Requirements', score: result.health_safety, weight: '10%', comment: result.comments_health_safety },
                { name: 'Connectivity and Theoretical Knowledge', score: result.connectivity_knowledge, weight: '10%', comment: result.comments_connectivity },
                { name: 'Presentation of Report', score: result.report_presentation, weight: '15%', comment: result.comments_presentation },
                { name: 'Clarity of Language', score: result.clarity_language, weight: '10%', comment: result.comments_clarity },
                { name: 'Lifelong Learning Activities', score: result.lifelong_learning, weight: '15%', comment: result.comments_lifelong },
                { name: 'Project Management', score: result.project_management, weight: '15%', comment: result.comments_project_mgmt },
                { name: 'Time Management', score: result.time_management, weight: '15%', comment: result.comments_time_mgmt }
            ];
            
            let breakdownHTML = '';
            let commentsHTML = '';
            
            components.forEach((comp, index) => {
                breakdownHTML += `
                    <div class="score-item score-name">${comp.name}</div>
                    <div class="score-item score-value">${parseFloat(comp.score).toFixed(1)}</div>
                    <div class="score-item score-weighted">${comp.weight}</div>
                `;
                
                if (comp.comment) {
                    commentsHTML += `
                        <div class="comments-section">
                            <div class="comment-label">${comp.name}</div>
                            <div class="comment-text">${comp.comment}</div>
                        </div>
                    `;
                }
            });
            
            document.getElementById('score_breakdown_content').innerHTML = breakdownHTML;
            document.getElementById('comments_content').innerHTML = commentsHTML || '<p style="color: #999;">No specific comments provided.</p>';
            
            // General feedback
            document.getElementById('modal_general_feedback').textContent = result.general_feedback || 'No general feedback provided.';
            
            // Assessment date
            const assessedDate = new Date(result.assessed_at);
            document.getElementById('modal_assessed_at').textContent = assessedDate.toLocaleDateString('en-US', { 
                month: 'long', 
                day: 'numeric', 
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            // Show modal
            document.getElementById('detailsModal').style.display = 'block';
        }
        
        function closeModal() {
            document.getElementById('detailsModal').style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('detailsModal');
            if (event.target === modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>