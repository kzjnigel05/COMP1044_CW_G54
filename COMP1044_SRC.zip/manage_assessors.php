<?php
/**
 * Manage Assessors
 * Admin interface for adding, editing, and deleting assessor accounts
 * COMP1044 Assignment
 */

require_once 'session.php';
require_once 'db_connect.php';

// Require admin privileges
require_admin();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Add new assessor
    if ($action === 'add') {
        $username = sanitize_input($conn, $_POST['username']);
        $password = $_POST['password'];
        $full_name = sanitize_input($conn, $_POST['full_name']);
        $email = sanitize_input($conn, $_POST['email']);
        
        // Validate inputs
        if (empty($username) || empty($password) || empty($full_name)) {
            set_error_message("Please fill in all required fields.");
        } elseif (strlen($password) < 6) {
            set_error_message("Password must be at least 6 characters long.");
        } elseif (!empty($email) && !validate_email($email)) {
            set_error_message("Invalid email format.");
        } else {
            // Check if username already exists
            $check_sql = "SELECT user_id FROM users WHERE username = ?";
            $stmt = mysqli_prepare($conn, $check_sql);
            mysqli_stmt_bind_param($stmt, "s", $username);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            if (mysqli_num_rows($result) > 0) {
                set_error_message("Username already exists.");
            } else {
                // Hash password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                // Insert new assessor
                $sql = "INSERT INTO users (username, password, full_name, email, role, created_at) 
                        VALUES (?, ?, ?, ?, 'Assessor', NOW())";
                $stmt = mysqli_prepare($conn, $sql);
                
                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, "ssss", $username, $hashed_password, $full_name, $email);
                    
                    if (mysqli_stmt_execute($stmt)) {
                        log_activity($conn, $_SESSION['user_id'], 'Add Assessor', "Added assessor: $username - $full_name");
                        set_success_message("Assessor added successfully!");
                    } else {
                        set_error_message("Error adding assessor. Please try again.");
                    }
                    mysqli_stmt_close($stmt);
                }
            }
        }
        
        header("Location: manage_assessors.php");
        exit();
    }
    
    // Update assessor
    elseif ($action === 'update') {
        $user_id = intval($_POST['user_id']);
        $username = sanitize_input($conn, $_POST['username']);
        $full_name = sanitize_input($conn, $_POST['full_name']);
        $email = sanitize_input($conn, $_POST['email']);
        $new_password = $_POST['new_password'] ?? '';
        
        // Validate inputs
        if (empty($username) || empty($full_name)) {
            set_error_message("Please fill in all required fields.");
        } elseif (!empty($email) && !validate_email($email)) {
            set_error_message("Invalid email format.");
        } elseif (!empty($new_password) && strlen($new_password) < 6) {
            set_error_message("Password must be at least 6 characters long.");
        } else {
            // Check if username conflicts with another user
            $check_sql = "SELECT user_id FROM users WHERE username = ? AND user_id != ?";
            $stmt = mysqli_prepare($conn, $check_sql);
            mysqli_stmt_bind_param($stmt, "si", $username, $user_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            if (mysqli_num_rows($result) > 0) {
                set_error_message("Username already exists for another user.");
            } else {
                // Update assessor
                if (!empty($new_password)) {
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $sql = "UPDATE users 
                            SET username = ?, password = ?, full_name = ?, email = ?, updated_at = NOW() 
                            WHERE user_id = ?";
                    $stmt = mysqli_prepare($conn, $sql);
                    mysqli_stmt_bind_param($stmt, "ssssi", $username, $hashed_password, $full_name, $email, $user_id);
                } else {
                    $sql = "UPDATE users 
                            SET username = ?, full_name = ?, email = ?, updated_at = NOW() 
                            WHERE user_id = ?";
                    $stmt = mysqli_prepare($conn, $sql);
                    mysqli_stmt_bind_param($stmt, "sssi", $username, $full_name, $email, $user_id);
                }
                
                if ($stmt && mysqli_stmt_execute($stmt)) {
                    log_activity($conn, $_SESSION['user_id'], 'Update Assessor', "Updated assessor: $username - $full_name");
                    set_success_message("Assessor updated successfully!");
                } else {
                    set_error_message("Error updating assessor. Please try again.");
                }
                
                mysqli_stmt_close($stmt);
            }
        }
        
        header("Location: manage_assessors.php");
        exit();
    }
    
    // Delete assessor
    elseif ($action === 'delete') {
        $user_id = intval($_POST['user_id']);
        
        // Check if assessor has assigned students
        $check_sql = "SELECT COUNT(*) as count FROM internships WHERE assessor_id = ?";
        $stmt = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);
        
        if ($row['count'] > 0) {
            set_error_message("Cannot delete assessor. Assessor has assigned students.");
        } else {
            // Soft delete (set is_active to 0)
            $sql = "UPDATE users SET is_active = 0, updated_at = NOW() WHERE user_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "i", $user_id);
                
                if (mysqli_stmt_execute($stmt)) {
                    log_activity($conn, $_SESSION['user_id'], 'Delete Assessor', "Deleted assessor ID: $user_id");
                    set_success_message("Assessor deleted successfully!");
                } else {
                    set_error_message("Error deleting assessor. Please try again.");
                }
                mysqli_stmt_close($stmt);
            }
        }
        
        header("Location: manage_assessors.php");
        exit();
    }
}

// Fetch all active assessors
$assessors = array();
$search = isset($_GET['search']) ? sanitize_input($conn, $_GET['search']) : '';

if (!empty($search)) {
    $search_term = "%$search%";
    $sql = "SELECT user_id, username, full_name, email, created_at 
            FROM users 
            WHERE role = 'Assessor' AND is_active = 1 
            AND (username LIKE ? OR full_name LIKE ? OR email LIKE ?) 
            ORDER BY full_name ASC";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sss", $search_term, $search_term, $search_term);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    $sql = "SELECT user_id, username, full_name, email, created_at 
            FROM users 
            WHERE role = 'Assessor' AND is_active = 1 
            ORDER BY full_name ASC";
    $result = mysqli_query($conn, $sql);
}

while ($row = mysqli_fetch_assoc($result)) {
    // Get number of assigned students
    $count_sql = "SELECT COUNT(*) as student_count FROM internships WHERE assessor_id = ?";
    $stmt = mysqli_prepare($conn, $count_sql);
    mysqli_stmt_bind_param($stmt, "i", $row['user_id']);
    mysqli_stmt_execute($stmt);
    $count_result = mysqli_stmt_get_result($stmt);
    $count_row = mysqli_fetch_assoc($count_result);
    
    $row['student_count'] = $count_row['student_count'];
    $assessors[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Assessors - Internship Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .navbar h1 {
            font-size: 24px;
        }
        
        .btn-back {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 1px solid white;
            padding: 8px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s;
        }
        
        .btn-back:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 30px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .page-header h2 {
            color: #333;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
            transition: transform 0.2s;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        
        .search-bar {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .search-bar form {
            display: flex;
            gap: 10px;
        }
        
        .search-bar input {
            flex: 1;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .search-bar button {
            padding: 10px 25px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        
        .table-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: #f8f9fa;
        }
        
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #333;
            border-bottom: 2px solid #e0e0e0;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            color: #666;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        
        .btn-edit, .btn-delete {
            padding: 6px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
        }
        
        .btn-edit {
            background: #2196f3;
            color: white;
        }
        
        .btn-delete {
            background: #f44336;
            color: white;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background-color: #e8f5e9;
            border-left: 4px solid #4caf50;
            color: #2e7d32;
        }
        
        .alert-error {
            background-color: #fee;
            border-left: 4px solid #f44336;
            color: #c33;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        
        .form-group input {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
        }
        
        .required {
            color: red;
        }
        
        .no-records {
            padding: 40px;
            text-align: center;
            color: #999;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 10px;
            background: #e3f2fd;
            color: #1976d2;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-content">
            <h1>Manage Assessors</h1>
            <a href="admin_dashboard.php" class="btn-back">← Back to Dashboard</a>
        </div>
    </nav>
    
    <div class="container">
        <?php 
        $success_msg = get_success_message();
        if (!empty($success_msg)): 
        ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success_msg); ?>
            </div>
        <?php endif; ?>
        
        <?php 
        $error_msg = get_error_message();
        if (!empty($error_msg)): 
        ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($error_msg); ?>
            </div>
        <?php endif; ?>
        
        <div class="page-header">
            <h2>Assessor Management</h2>
            <button class="btn-primary" onclick="openAddModal()">+ Add New Assessor</button>
        </div>
        
        <div class="search-bar">
            <form method="GET">
                <input type="text" name="search" placeholder="Search by username, name, or email..." 
                       value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Search</button>
                <?php if (!empty($search)): ?>
                    <a href="manage_assessors.php" class="btn-primary">Clear</a>
                <?php endif; ?>
            </form>
        </div>
        
        <div class="table-container">
            <?php if (count($assessors) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Assigned Students</th>
                            <th>Created Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($assessors as $assessor): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($assessor['username']); ?></td>
                                <td><?php echo htmlspecialchars($assessor['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($assessor['email'] ?: '-'); ?></td>
                                <td><span class="badge"><?php echo $assessor['student_count']; ?> students</span></td>
                                <td><?php echo date('M d, Y', strtotime($assessor['created_at'])); ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn-edit" onclick='openEditModal(<?php echo json_encode($assessor); ?>)'>Edit</button>
                                        <button class="btn-delete" onclick="confirmDelete(<?php echo $assessor['user_id']; ?>, '<?php echo htmlspecialchars($assessor['full_name']); ?>')">Delete</button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-records">No assessors found.</div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Add Assessor Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeAddModal()">&times;</span>
            <h2>Add New Assessor</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label>Username <span class="required">*</span></label>
                    <input type="text" name="username" required maxlength="50">
                </div>
                
                <div class="form-group">
                    <label>Password <span class="required">*</span></label>
                    <input type="password" name="password" required minlength="6">
                    <small style="color: #666;">Minimum 6 characters</small>
                </div>
                
                <div class="form-group">
                    <label>Full Name <span class="required">*</span></label>
                    <input type="text" name="full_name" required maxlength="100">
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" maxlength="100">
                </div>
                
                <button type="submit" class="btn-primary">Add Assessor</button>
            </form>
        </div>
    </div>
    
    <!-- Edit Assessor Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <h2>Edit Assessor</h2>
            <form method="POST">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="user_id" id="edit_user_id">
                
                <div class="form-group">
                    <label>Username <span class="required">*</span></label>
                    <input type="text" name="username" id="edit_username" required>
                </div>
                
                <div class="form-group">
                    <label>New Password</label>
                    <input type="password" name="new_password" id="edit_password" minlength="6">
                    <small style="color: #666;">Leave blank to keep current password</small>
                </div>
                
                <div class="form-group">
                    <label>Full Name <span class="required">*</span></label>
                    <input type="text" name="full_name" id="edit_full_name" required>
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" id="edit_email">
                </div>
                
                <button type="submit" class="btn-primary">Update Assessor</button>
            </form>
        </div>
    </div>
    
    <form method="POST" id="deleteForm">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="user_id" id="delete_user_id">
    </form>
    
    <script>
        function openAddModal() {
            document.getElementById('addModal').style.display = 'block';
        }
        
        function closeAddModal() {
            document.getElementById('addModal').style.display = 'none';
        }
        
        function openEditModal(assessor) {
            document.getElementById('edit_user_id').value = assessor.user_id;
            document.getElementById('edit_username').value = assessor.username;
            document.getElementById('edit_full_name').value = assessor.full_name;
            document.getElementById('edit_email').value = assessor.email || '';
            document.getElementById('edit_password').value = '';
            document.getElementById('editModal').style.display = 'block';
        }
        
        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }
        
        function confirmDelete(userId, name) {
            if (confirm('Are you sure you want to delete assessor "' + name + '"?')) {
                document.getElementById('delete_user_id').value = userId;
                document.getElementById('deleteForm').submit();
            }
        }
        
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>
