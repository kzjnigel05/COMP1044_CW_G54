<?php
/**
 * Manage Internships
 * Admin interface for managing internship assignments
 * COMP1044 Assignment
 */

require_once 'session.php';
require_once 'db_connect.php';

// Require admin privileges
require_admin();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Add new internship
    if ($action === 'add') {
        $student_id = intval($_POST['student_id']);
        $assessor_id = intval($_POST['assessor_id']);
        $company_name = sanitize_input($conn, $_POST['company_name']);
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'];
        
        // Validate inputs
        if (empty($student_id) || empty($assessor_id) || empty($company_name)) {
            set_error_message("Please fill in all required fields.");
        } elseif (!empty($start_date) && !empty($end_date) && $start_date > $end_date) {
            set_error_message("End date must be after start date.");
        } else {
            // Check if student already has an internship
            $check_sql = "SELECT internship_id FROM internships WHERE student_id = ?";
            $stmt = mysqli_prepare($conn, $check_sql);
            mysqli_stmt_bind_param($stmt, "i", $student_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            if (mysqli_num_rows($result) > 0) {
                set_error_message("This student already has an internship assigned.");
            } else {
                // Insert new internship
                $sql = "INSERT INTO internships (student_id, assessor_id, company_name, internship_start_date, internship_end_date, created_at) 
                        VALUES (?, ?, ?, ?, ?, NOW())";
                $stmt = mysqli_prepare($conn, $sql);
                
                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, "iisss", $student_id, $assessor_id, $company_name, $start_date, $end_date);
                    
                    if (mysqli_stmt_execute($stmt)) {
                        log_activity($conn, $_SESSION['user_id'], 'Add Internship', "Assigned student ID $student_id to $company_name");
                        set_success_message("Internship added successfully!");
                    } else {
                        set_error_message("Error adding internship. Please try again.");
                    }
                    mysqli_stmt_close($stmt);
                }
            }
        }
        
        header("Location: manage_internships.php");
        exit();
    }
    
    // Update internship
    elseif ($action === 'update') {
        $internship_id = intval($_POST['internship_id']);
        $student_id = intval($_POST['student_id']);
        $assessor_id = intval($_POST['assessor_id']);
        $company_name = sanitize_input($conn, $_POST['company_name']);
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'];
        
        if (empty($student_id) || empty($assessor_id) || empty($company_name)) {
            set_error_message("Please fill in all required fields.");
        } elseif (!empty($start_date) && !empty($end_date) && $start_date > $end_date) {
            set_error_message("End date must be after start date.");
        } else {
            $sql = "UPDATE internships 
                    SET student_id = ?, assessor_id = ?, company_name = ?, 
                        internship_start_date = ?, internship_end_date = ?, updated_at = NOW() 
                    WHERE internship_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "iisssi", $student_id, $assessor_id, $company_name, $start_date, $end_date, $internship_id);
                
                if (mysqli_stmt_execute($stmt)) {
                    log_activity($conn, $_SESSION['user_id'], 'Update Internship', "Updated internship ID $internship_id");
                    set_success_message("Internship updated successfully!");
                } else {
                    set_error_message("Error updating internship. Please try again.");
                }
                mysqli_stmt_close($stmt);
            }
        }
        
        header("Location: manage_internships.php");
        exit();
    }
    
    // Delete internship
    elseif ($action === 'delete') {
        $internship_id = intval($_POST['internship_id']);
        
        // Check if internship has assessment
        $check_sql = "SELECT assessment_id FROM assessments WHERE internship_id = ?";
        $stmt = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($stmt, "i", $internship_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if (mysqli_num_rows($result) > 0) {
            set_error_message("Cannot delete internship. Assessment already exists.");
        } else {
            $sql = "DELETE FROM internships WHERE internship_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "i", $internship_id);
                
                if (mysqli_stmt_execute($stmt)) {
                    log_activity($conn, $_SESSION['user_id'], 'Delete Internship', "Deleted internship ID $internship_id");
                    set_success_message("Internship deleted successfully!");
                } else {
                    set_error_message("Error deleting internship. Please try again.");
                }
                mysqli_stmt_close($stmt);
            }
        }
        
        header("Location: manage_internships.php");
        exit();
    }
}

// Fetch internships with student and assessor details
$internships = array();
$search = isset($_GET['search']) ? sanitize_input($conn, $_GET['search']) : '';

if (!empty($search)) {
    $search_term = "%$search%";
    $sql = "SELECT i.*, s.student_id, s.student_name, s.programme, u.full_name as assessor_name
            FROM internships i
            JOIN students s ON i.student_id = s.id
            JOIN users u ON i.assessor_id = u.user_id
            WHERE s.student_id LIKE ? OR s.student_name LIKE ? OR i.company_name LIKE ?
            ORDER BY i.created_at DESC";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sss", $search_term, $search_term, $search_term);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    $sql = "SELECT i.*, s.student_id, s.student_name, s.programme, u.full_name as assessor_name
            FROM internships i
            JOIN students s ON i.student_id = s.id
            JOIN users u ON i.assessor_id = u.user_id
            ORDER BY i.created_at DESC";
    $result = mysqli_query($conn, $sql);
}

while ($row = mysqli_fetch_assoc($result)) {
    // Check if assessment exists
    $check_sql = "SELECT assessment_id FROM assessments WHERE internship_id = ?";
    $stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($stmt, "i", $row['internship_id']);
    mysqli_stmt_execute($stmt);
    $check_result = mysqli_stmt_get_result($stmt);
    $row['has_assessment'] = mysqli_num_rows($check_result) > 0;
    
    $internships[] = $row;
}

// Get available students (not yet assigned)
$available_students = array();
$sql = "SELECT s.* FROM students s 
        LEFT JOIN internships i ON s.id = i.student_id 
        WHERE s.is_active = 1 AND i.internship_id IS NULL 
        ORDER BY s.student_name";
$result = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($result)) {
    $available_students[] = $row;
}

// Get all students for edit
$all_students = array();
$sql = "SELECT * FROM students WHERE is_active = 1 ORDER BY student_name";
$result = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($result)) {
    $all_students[] = $row;
}

// Get all assessors
$assessors = array();
$sql = "SELECT user_id, full_name FROM users WHERE role = 'Assessor' AND is_active = 1 ORDER BY full_name";
$result = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($result)) {
    $assessors[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Internships - Internship Management</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; }
        .navbar { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .navbar-content { display: flex; justify-content: space-between; align-items: center; max-width: 1400px; margin: 0 auto; }
        .navbar h1 { font-size: 24px; }
        .btn-back { background: rgba(255,255,255,0.2); color: white; border: 1px solid white; padding: 8px 20px; border-radius: 5px; text-decoration: none; font-size: 14px; transition: background 0.3s; }
        .btn-back:hover { background: rgba(255,255,255,0.3); }
        .container { max-width: 1400px; margin: 30px auto; padding: 0 30px; }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .page-header h2 { color: #333; }
        .btn-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; padding: 10px 25px; border-radius: 5px; cursor: pointer; font-size: 14px; font-weight: 500; text-decoration: none; display: inline-block; transition: transform 0.2s; }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4); }
        .search-bar { background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .search-bar form { display: flex; gap: 10px; }
        .search-bar input { flex: 1; padding: 10px 15px; border: 2px solid #e0e0e0; border-radius: 5px; font-size: 14px; }
        .search-bar button { padding: 10px 25px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 5px; cursor: pointer; }
        .table-container { background: white; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; min-width: 900px; }
        thead { background: #f8f9fa; }
        th { padding: 15px; text-align: left; font-weight: 600; color: #333; border-bottom: 2px solid #e0e0e0; }
        td { padding: 15px; border-bottom: 1px solid #e0e0e0; color: #666; }
        tr:hover { background: #f8f9fa; }
        .action-buttons { display: flex; gap: 10px; }
        .btn-edit, .btn-delete { padding: 6px 15px; border: none; border-radius: 4px; cursor: pointer; font-size: 13px; }
        .btn-edit { background: #2196f3; color: white; }
        .btn-delete { background: #f44336; color: white; }
        .alert { padding: 15px 20px; border-radius: 5px; margin-bottom: 20px; }
        .alert-success { background-color: #e8f5e9; border-left: 4px solid #4caf50; color: #2e7d32; }
        .alert-error { background-color: #fee; border-left: 4px solid #f44336; color: #c33; }
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); }
        .modal-content { background-color: white; margin: 5% auto; padding: 30px; border-radius: 10px; width: 90%; max-width: 600px; }
        .close { color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; color: #333; font-weight: 500; }
        .form-group input, .form-group select { width: 100%; padding: 10px 15px; border: 2px solid #e0e0e0; border-radius: 5px; }
        .required { color: red; }
        .no-records { padding: 40px; text-align: center; color: #999; }
        .badge { display: inline-block; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 500; }
        .badge-success { background: #e8f5e9; color: #2e7d32; }
        .badge-warning { background: #fff3e0; color: #e65100; }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-content">
            <h1>Manage Internships</h1>
            <a href="admin_dashboard.php" class="btn-back">← Back to Dashboard</a>
        </div>
    </nav>
    
    <div class="container">
        <?php if ($msg = get_success_message()): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div>
        <?php endif; ?>
        
        <?php if ($msg = get_error_message()): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($msg); ?></div>
        <?php endif; ?>
        
        <div class="page-header">
            <h2>Internship Management</h2>
            <button class="btn-primary" onclick="openAddModal()">+ Add New Internship</button>
        </div>
        
        <div class="search-bar">
            <form method="GET">
                <input type="text" name="search" placeholder="Search by student ID, name, or company..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Search</button>
                <?php if (!empty($search)): ?>
                    <a href="manage_internships.php" class="btn-primary">Clear</a>
                <?php endif; ?>
            </form>
        </div>
        
        <div class="table-container">
            <?php if (count($internships) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Programme</th>
                            <th>Company</th>
                            <th>Assessor</th>
                            <th>Dates</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($internships as $int): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($int['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($int['student_name']); ?></td>
                                <td><?php echo htmlspecialchars($int['programme']); ?></td>
                                <td><?php echo htmlspecialchars($int['company_name']); ?></td>
                                <td><?php echo htmlspecialchars($int['assessor_name']); ?></td>
                                <td>
                                    <?php 
                                    if ($int['internship_start_date'] && $int['internship_end_date']) {
                                        echo date('M d, Y', strtotime($int['internship_start_date'])) . ' - ' . 
                                             date('M d, Y', strtotime($int['internship_end_date']));
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php if ($int['has_assessment']): ?>
                                        <span class="badge badge-success">Assessed</span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn-edit" onclick='openEditModal(<?php echo json_encode($int); ?>)'>Edit</button>
                                        <button class="btn-delete" onclick="confirmDelete(<?php echo $int['internship_id']; ?>, '<?php echo htmlspecialchars($int['student_name']); ?>')">Delete</button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-records">No internships found.</div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Add Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeAddModal()">&times;</span>
            <h2>Add New Internship</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label>Student <span class="required">*</span></label>
                    <select name="student_id" required>
                        <option value="">-- Select Student --</option>
                        <?php foreach ($available_students as $student): ?>
                            <option value="<?php echo $student['id']; ?>">
                                <?php echo htmlspecialchars($student['student_id'] . ' - ' . $student['student_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Assessor <span class="required">*</span></label>
                    <select name="assessor_id" required>
                        <option value="">-- Select Assessor --</option>
                        <?php foreach ($assessors as $assessor): ?>
                            <option value="<?php echo $assessor['user_id']; ?>">
                                <?php echo htmlspecialchars($assessor['full_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Company Name <span class="required">*</span></label>
                    <input type="text" name="company_name" required maxlength="150">
                </div>
                
                <div class="form-group">
                    <label>Start Date</label>
                    <input type="date" name="start_date">
                </div>
                
                <div class="form-group">
                    <label>End Date</label>
                    <input type="date" name="end_date">
                </div>
                
                <button type="submit" class="btn-primary">Add Internship</button>
            </form>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <h2>Edit Internship</h2>
            <form method="POST">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="internship_id" id="edit_internship_id">
                
                <div class="form-group">
                    <label>Student <span class="required">*</span></label>
                    <select name="student_id" id="edit_student_id" required>
                        <?php foreach ($all_students as $student): ?>
                            <option value="<?php echo $student['id']; ?>">
                                <?php echo htmlspecialchars($student['student_id'] . ' - ' . $student['student_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Assessor <span class="required">*</span></label>
                    <select name="assessor_id" id="edit_assessor_id" required>
                        <?php foreach ($assessors as $assessor): ?>
                            <option value="<?php echo $assessor['user_id']; ?>">
                                <?php echo htmlspecialchars($assessor['full_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Company Name <span class="required">*</span></label>
                    <input type="text" name="company_name" id="edit_company_name" required>
                </div>
                
                <div class="form-group">
                    <label>Start Date</label>
                    <input type="date" name="start_date" id="edit_start_date">
                </div>
                
                <div class="form-group">
                    <label>End Date</label>
                    <input type="date" name="end_date" id="edit_end_date">
                </div>
                
                <button type="submit" class="btn-primary">Update Internship</button>
            </form>
        </div>
    </div>
    
    <form method="POST" id="deleteForm">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="internship_id" id="delete_internship_id">
    </form>
    
    <script>
        function openAddModal() { document.getElementById('addModal').style.display = 'block'; }
        function closeAddModal() { document.getElementById('addModal').style.display = 'none'; }
        
        function openEditModal(internship) {
            document.getElementById('edit_internship_id').value = internship.internship_id;
            document.getElementById('edit_student_id').value = internship.student_id;
            document.getElementById('edit_assessor_id').value = internship.assessor_id;
            document.getElementById('edit_company_name').value = internship.company_name;
            document.getElementById('edit_start_date').value = internship.internship_start_date || '';
            document.getElementById('edit_end_date').value = internship.internship_end_date || '';
            document.getElementById('editModal').style.display = 'block';
        }
        
        function closeEditModal() { document.getElementById('editModal').style.display = 'none'; }
        
        function confirmDelete(id, name) {
            if (confirm('Are you sure you want to delete the internship for "' + name + '"?')) {
                document.getElementById('delete_internship_id').value = id;
                document.getElementById('deleteForm').submit();
            }
        }
        
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>
