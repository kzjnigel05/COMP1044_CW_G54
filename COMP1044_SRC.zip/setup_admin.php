<?php
/**
 * Admin Password Setup Script
 * Run this file ONCE to fix the admin password issue
 * Access via: http://localhost/your-folder/setup_admin.php
 */

// Database configuration - UPDATE THESE IF NEEDED
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');
define('DB_NAME', 'comp1044_database');

// Connect to database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "<h2>Admin Password Setup</h2>";
echo "<p>Database: " . DB_NAME . "</p>";

// The password we want to set
$username = 'admin';
$password = 'admin123';
$full_name = 'System Administrator';
$email = 'admin@university.edu';

// Generate password hash
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

echo "<p>Generated password hash: <code>" . htmlspecialchars($hashed_password) . "</code></p>";

// Check if admin user exists
$check_sql = "SELECT user_id, username FROM users WHERE username = ?";
$stmt = mysqli_prepare($conn, $check_sql);
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    // Admin exists, update password
    echo "<p><strong>Admin user found. Updating password...</strong></p>";
    
    $update_sql = "UPDATE users SET password = ? WHERE username = ?";
    $stmt = mysqli_prepare($conn, $update_sql);
    mysqli_stmt_bind_param($stmt, "ss", $hashed_password, $username);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "<div style='background: #d4edda; border-left: 4px solid #28a745; padding: 15px; margin: 20px 0;'>";
        echo "<strong>✓ SUCCESS!</strong><br>";
        echo "Admin password has been updated successfully!<br><br>";
        echo "<strong>Login Credentials:</strong><br>";
        echo "Username: <code>admin</code><br>";
        echo "Password: <code>admin123</code>";
        echo "</div>";
        
        // Test the password
        $verify_sql = "SELECT password FROM users WHERE username = ?";
        $stmt = mysqli_prepare($conn, $verify_sql);
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $verify_result = mysqli_stmt_get_result($stmt);
        $verify_row = mysqli_fetch_assoc($verify_result);
        
        if (password_verify($password, $verify_row['password'])) {
            echo "<p style='color: green;'><strong>✓ Password verification test: PASSED</strong></p>";
        } else {
            echo "<p style='color: red;'><strong>✗ Password verification test: FAILED</strong></p>";
        }
    } else {
        echo "<p style='color: red;'><strong>Error updating password:</strong> " . mysqli_error($conn) . "</p>";
    }
} else {
    // Admin doesn't exist, create new
    echo "<p><strong>Admin user not found. Creating new admin account...</strong></p>";
    
    $insert_sql = "INSERT INTO users (username, password, full_name, email, role, is_active, created_at) 
                   VALUES (?, ?, ?, ?, 'Admin', 1, NOW())";
    $stmt = mysqli_prepare($conn, $insert_sql);
    mysqli_stmt_bind_param($stmt, "ssss", $username, $hashed_password, $full_name, $email);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "<div style='background: #d4edda; border-left: 4px solid #28a745; padding: 15px; margin: 20px 0;'>";
        echo "<strong>✓ SUCCESS!</strong><br>";
        echo "Admin account has been created successfully!<br><br>";
        echo "<strong>Login Credentials:</strong><br>";
        echo "Username: <code>admin</code><br>";
        echo "Password: <code>admin123</code>";
        echo "</div>";
    } else {
        echo "<p style='color: red;'><strong>Error creating admin:</strong> " . mysqli_error($conn) . "</p>";
    }
}

mysqli_close($conn);

echo "<hr>";
echo "<h3>Next Steps:</h3>";
echo "<ol>";
echo "<li>Go to <a href='login.php'>login.php</a></li>";
echo "<li>Login with username: <code>admin</code> and password: <code>admin123</code></li>";
echo "<li><strong>IMPORTANT:</strong> Delete this file (setup_admin.php) after successful login for security!</li>";
echo "</ol>";

echo "<hr>";
echo "<h3>Also Update Assessor Passwords (Optional)</h3>";
echo "<p>If assessor logins also fail, run this SQL command:</p>";
echo "<pre style='background: #f5f5f5; padding: 10px; border: 1px solid #ddd;'>";
echo "UPDATE users SET password = '" . $hashed_password . "' WHERE role = 'Assessor';";
echo "</pre>";
?>

<style>
body {
    font-family: Arial, sans-serif;
    max-width: 800px;
    margin: 50px auto;
    padding: 20px;
    background: #f5f5f5;
}
h2 {
    color: #333;
    border-bottom: 2px solid #667eea;
    padding-bottom: 10px;
}
code {
    background: #f0f0f0;
    padding: 2px 6px;
    border-radius: 3px;
    color: #c7254e;
    font-family: monospace;
}
pre {
    overflow-x: auto;
}
</style>