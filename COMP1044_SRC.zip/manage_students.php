<?php
/**
 * Manage Students
 * Admin interface for adding, editing, and deleting student records
 * COMP1044 Assignment
 */

require_once 'session.php';
require_once 'db_connect.php';

// Require admin privileges
require_admin();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Add new student
    if ($action === 'add') {
        $student_id = sanitize_input($conn, $_POST['student_id']);
        $student_name = sanitize_input($conn, $_POST['student_name']);
        $programme = sanitize_input($conn, $_POST['programme']);
        $email = sanitize_input($conn, $_POST['email']);
        $phone = sanitize_input($conn, $_POST['phone']);
        
        // Validate inputs
        if (empty($student_id) || empty($student_name) || empty($programme)) {
            set_error_message("Please fill in all required fields.");
        } elseif (!empty($email) && !validate_email($email)) {
            set_error_message("Invalid email format.");
        } else {
            // Check if student ID already exists
            $check_sql = "SELECT student_id FROM students WHERE student_id = ?";
            $stmt = mysqli_prepare($conn, $check_sql);
            mysqli_stmt_bind_param($stmt, "s", $student_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            if (mysqli_num_rows($result) > 0) {
                set_error_message("Student ID already exists.");
            } else {
                // Insert new student
                $sql = "INSERT INTO students (student_id, student_name, programme, email, phone, created_at) 
                        VALUES (?, ?, ?, ?, ?, NOW())";
                $stmt = mysqli_prepare($conn, $sql);
                
                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, "sssss", $student_id, $student_name, $programme, $email, $phone);
                    
                    if (mysqli_stmt_execute($stmt)) {
                        log_activity($conn, $_SESSION['user_id'], 'Add Student', "Added student: $student_id - $student_name");
                        set_success_message("Student added successfully!");
                    } else {
                        set_error_message("Error adding student. Please try again.");
                    }
                    mysqli_stmt_close($stmt);
                } else {
                    set_error_message("Database error. Please try again.");
                }
            }
        }
        
        header("Location: manage_students.php");
        exit();
    }
    
    // Update student
    elseif ($action === 'update') {
        $id = intval($_POST['id']);
        $student_id = sanitize_input($conn, $_POST['student_id']);
        $student_name = sanitize_input($conn, $_POST['student_name']);
        $programme = sanitize_input($conn, $_POST['programme']);
        $email = sanitize_input($conn, $_POST['email']);
        $phone = sanitize_input($conn, $_POST['phone']);
        
        // Validate inputs
        if (empty($student_id) || empty($student_name) || empty($programme)) {
            set_error_message("Please fill in all required fields.");
        } elseif (!empty($email) && !validate_email($email)) {
            set_error_message("Invalid email format.");
        } else {
            // Check if new student ID conflicts with another record
            $check_sql = "SELECT id FROM students WHERE student_id = ? AND id != ?";
            $stmt = mysqli_prepare($conn, $check_sql);
            mysqli_stmt_bind_param($stmt, "si", $student_id, $id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            if (mysqli_num_rows($result) > 0) {
                set_error_message("Student ID already exists for another student.");
            } else {
                // Update student
                $sql = "UPDATE students 
                        SET student_id = ?, student_name = ?, programme = ?, email = ?, phone = ?, updated_at = NOW() 
                        WHERE id = ?";
                $stmt = mysqli_prepare($conn, $sql);
                
                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, "sssssi", $student_id, $student_name, $programme, $email, $phone, $id);
                    
                    if (mysqli_stmt_execute($stmt)) {
                        log_activity($conn, $_SESSION['user_id'], 'Update Student', "Updated student: $student_id - $student_name");
                        set_success_message("Student updated successfully!");
                    } else {
                        set_error_message("Error updating student. Please try again.");
                    }
                    mysqli_stmt_close($stmt);
                } else {
                    set_error_message("Database error. Please try again.");
                }
            }
        }
        
        header("Location: manage_students.php");
        exit();
    }
    
    // Delete student
    elseif ($action === 'delete') {
        $id = intval($_POST['id']);
        
        // Check if student has internships
        $check_sql = "SELECT COUNT(*) as count FROM internships WHERE student_id = 
                      (SELECT id FROM students WHERE id = ?)";
        $stmt = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);
        
        if ($row['count'] > 0) {
            set_error_message("Cannot delete student. Student has associated internship records.");
        } else {
            // Soft delete (set is_active to 0)
            $sql = "UPDATE students SET is_active = 0, updated_at = NOW() WHERE id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "i", $id);
                
                if (mysqli_stmt_execute($stmt)) {
                    log_activity($conn, $_SESSION['user_id'], 'Delete Student', "Deleted student ID: $id");
                    set_success_message("Student deleted successfully!");
                } else {
                    set_error_message("Error deleting student. Please try again.");
                }
                mysqli_stmt_close($stmt);
            }
        }
        
        header("Location: manage_students.php");
        exit();
    }
}

// Fetch all active students
$students = array();
$search = isset($_GET['search']) ? sanitize_input($conn, $_GET['search']) : '';

if (!empty($search)) {
    $search_term = "%$search%";
    $sql = "SELECT * FROM students 
            WHERE is_active = 1 
            AND (student_id LIKE ? OR student_name LIKE ? OR programme LIKE ?) 
            ORDER BY student_name ASC";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sss", $search_term, $search_term, $search_term);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    $sql = "SELECT * FROM students WHERE is_active = 1 ORDER BY student_name ASC";
    $result = mysqli_query($conn, $sql);
}

while ($row = mysqli_fetch_assoc($result)) {
    $students[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students - Internship Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .navbar h1 {
            font-size: 24px;
        }
        
        .btn-back {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 1px solid white;
            padding: 8px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s;
        }
        
        .btn-back:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 30px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .page-header h2 {
            color: #333;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
            transition: transform 0.2s;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        
        .search-bar {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .search-bar form {
            display: flex;
            gap: 10px;
        }
        
        .search-bar input {
            flex: 1;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .search-bar input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .search-bar button {
            padding: 10px 25px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        
        .table-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: #f8f9fa;
        }
        
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #333;
            border-bottom: 2px solid #e0e0e0;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            color: #666;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        
        .btn-edit, .btn-delete {
            padding: 6px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-edit {
            background: #2196f3;
            color: white;
        }
        
        .btn-edit:hover {
            background: #1976d2;
        }
        
        .btn-delete {
            background: #f44336;
            color: white;
        }
        
        .btn-delete:hover {
            background: #d32f2f;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background-color: #e8f5e9;
            border-left: 4px solid #4caf50;
            color: #2e7d32;
        }
        
        .alert-error {
            background-color: #fee;
            border-left: 4px solid #f44336;
            color: #c33;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            line-height: 20px;
        }
        
        .close:hover {
            color: #000;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        
        .form-group input {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .required {
            color: red;
        }
        
        .no-records {
            padding: 40px;
            text-align: center;
            color: #999;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-content">
            <h1>Manage Students</h1>
            <a href="admin_dashboard.php" class="btn-back">← Back to Dashboard</a>
        </div>
    </nav>
    
    <div class="container">
        <?php 
        $success_msg = get_success_message();
        if (!empty($success_msg)): 
        ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success_msg); ?>
            </div>
        <?php endif; ?>
        
        <?php 
        $error_msg = get_error_message();
        if (!empty($error_msg)): 
        ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($error_msg); ?>
            </div>
        <?php endif; ?>
        
        <div class="page-header">
            <h2>Student Management</h2>
            <button class="btn-primary" onclick="openAddModal()">+ Add New Student</button>
        </div>
        
        <div class="search-bar">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search by Student ID, Name, or Programme..." 
                       value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Search</button>
                <?php if (!empty($search)): ?>
                    <a href="manage_students.php" class="btn-primary" style="padding: 10px 20px;">Clear</a>
                <?php endif; ?>
            </form>
        </div>
        
        <div class="table-container">
            <?php if (count($students) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Name</th>
                            <th>Programme</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($student['student_name']); ?></td>
                                <td><?php echo htmlspecialchars($student['programme']); ?></td>
                                <td><?php echo htmlspecialchars($student['email'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($student['phone'] ?: '-'); ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn-edit" onclick='openEditModal(<?php echo json_encode($student); ?>)'>Edit</button>
                                        <button class="btn-delete" onclick="confirmDelete(<?php echo $student['id']; ?>, '<?php echo htmlspecialchars($student['student_name']); ?>')">Delete</button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-records">
                    <?php if (!empty($search)): ?>
                        No students found matching "<?php echo htmlspecialchars($search); ?>"
                    <?php else: ?>
                        No students found. Click "Add New Student" to get started.
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Add Student Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeAddModal()">&times;</span>
            <h2>Add New Student</h2>
            <form method="POST" action="" id="addForm">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label>Student ID <span class="required">*</span></label>
                    <input type="text" name="student_id" required maxlength="20">
                </div>
                
                <div class="form-group">
                    <label>Student Name <span class="required">*</span></label>
                    <input type="text" name="student_name" required maxlength="100">
                </div>
                
                <div class="form-group">
                    <label>Programme <span class="required">*</span></label>
                    <input type="text" name="programme" required maxlength="100">
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" maxlength="100">
                </div>
                
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" name="phone" maxlength="20">
                </div>
                
                <button type="submit" class="btn-primary">Add Student</button>
            </form>
        </div>
    </div>
    
    <!-- Edit Student Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <h2>Edit Student</h2>
            <form method="POST" action="" id="editForm">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" id="edit_id">
                
                <div class="form-group">
                    <label>Student ID <span class="required">*</span></label>
                    <input type="text" name="student_id" id="edit_student_id" required maxlength="20">
                </div>
                
                <div class="form-group">
                    <label>Student Name <span class="required">*</span></label>
                    <input type="text" name="student_name" id="edit_student_name" required maxlength="100">
                </div>
                
                <div class="form-group">
                    <label>Programme <span class="required">*</span></label>
                    <input type="text" name="programme" id="edit_programme" required maxlength="100">
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" id="edit_email" maxlength="100">
                </div>
                
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" name="phone" id="edit_phone" maxlength="20">
                </div>
                
                <button type="submit" class="btn-primary">Update Student</button>
            </form>
        </div>
    </div>
    
    <!-- Delete Form (Hidden) -->
    <form method="POST" action="" id="deleteForm">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" id="delete_id">
    </form>
    
    <script>
        function openAddModal() {
            document.getElementById('addModal').style.display = 'block';
        }
        
        function closeAddModal() {
            document.getElementById('addModal').style.display = 'none';
            document.getElementById('addForm').reset();
        }
        
        function openEditModal(student) {
            document.getElementById('edit_id').value = student.id;
            document.getElementById('edit_student_id').value = student.student_id;
            document.getElementById('edit_student_name').value = student.student_name;
            document.getElementById('edit_programme').value = student.programme;
            document.getElementById('edit_email').value = student.email || '';
            document.getElementById('edit_phone').value = student.phone || '';
            document.getElementById('editModal').style.display = 'block';
        }
        
        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
            document.getElementById('editForm').reset();
        }
        
        function confirmDelete(id, name) {
            if (confirm('Are you sure you want to delete student "' + name + '"?\n\nThis action cannot be undone.')) {
                document.getElementById('delete_id').value = id;
                document.getElementById('deleteForm').submit();
            }
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const addModal = document.getElementById('addModal');
            const editModal = document.getElementById('editModal');
            
            if (event.target === addModal) {
                closeAddModal();
            }
            if (event.target === editModal) {
                closeEditModal();
            }
        }
    </script>
</body>
</html>
