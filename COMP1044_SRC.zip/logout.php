<?php
/**
 * Logout Script
 * Handles user logout and session cleanup
 * COMP1044 Assignment
 */

require_once 'session.php';
require_once 'db_connect.php';

// Log the logout activity if user is logged in
if (is_logged_in()) {
    log_activity($conn, $_SESSION['user_id'], 'Logout', 'User logged out');
}

// Set success message before destroying session
set_success_message("You have been successfully logged out.");

// Call the logout function from session.php
logout_user();
?>
