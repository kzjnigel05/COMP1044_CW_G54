<?php
/**
 * Assessor Dashboard
 * Main dashboard for assessors to view and grade their assigned students
 * COMP1044 Assignment
 */

require_once 'session.php';
require_once 'db_connect.php';

// Require assessor privileges (crucial for security)
require_assessor();

$assessor_id = $_SESSION['user_id'];

// Fetch statistics for this specific assessor
$stats = array(
    'total_assigned' => 0,
    'pending_assessments' => 0,
    'completed_assessments' => 0,
    'average_score' => 0
);

// Get total assigned students for this assessor
$sql = "SELECT COUNT(*) as count FROM internships WHERE assessor_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $assessor_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
if ($row = mysqli_fetch_assoc($result)) {
    $stats['total_assigned'] = $row['count'];
}
mysqli_stmt_close($stmt);

// Get completed assessments for this assessor
$sql = "SELECT COUNT(*) as count 
        FROM assessments a 
        JOIN internships i ON a.internship_id = i.internship_id 
        WHERE i.assessor_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $assessor_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
if ($row = mysqli_fetch_assoc($result)) {
    $stats['completed_assessments'] = $row['count'];
}
mysqli_stmt_close($stmt);

// Calculate pending
$stats['pending_assessments'] = $stats['total_assigned'] - $stats['completed_assessments'];

// Get average score given by this assessor
$sql = "SELECT AVG(a.final_score) as avg_score 
        FROM assessments a 
        JOIN internships i ON a.internship_id = i.internship_id 
        WHERE i.assessor_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $assessor_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
if ($row = mysqli_fetch_assoc($result)) {
    $stats['average_score'] = $row['avg_score'] ? round($row['avg_score'], 2) : 0;
}
mysqli_stmt_close($stmt);

// Fetch assigned students list
$assigned_students = array();
$search = isset($_GET['search']) ? sanitize_input($conn, $_GET['search']) : '';

if (!empty($search)) {
    $search_term = "%$search%";
    $sql = "SELECT i.internship_id, i.company_name, i.internship_start_date, i.internship_end_date, 
                   s.student_id, s.student_name, s.programme,
                   a.assessment_id, a.final_score
            FROM internships i
            JOIN students s ON i.student_id = s.id
            LEFT JOIN assessments a ON i.internship_id = a.internship_id
            WHERE i.assessor_id = ? AND (s.student_id LIKE ? OR s.student_name LIKE ? OR i.company_name LIKE ?)
            ORDER BY s.student_name ASC";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "isss", $assessor_id, $search_term, $search_term, $search_term);
} else {
    $sql = "SELECT i.internship_id, i.company_name, i.internship_start_date, i.internship_end_date, 
                   s.student_id, s.student_name, s.programme,
                   a.assessment_id, a.final_score
            FROM internships i
            JOIN students s ON i.student_id = s.id
            LEFT JOIN assessments a ON i.internship_id = a.internship_id
            WHERE i.assessor_id = ?
            ORDER BY s.student_name ASC";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $assessor_id);
}

mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
while ($row = mysqli_fetch_assoc($result)) {
    $assigned_students[] = $row;
}
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assessor Dashboard - Internship Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }
        
        .navbar {
            background: linear-gradient(135deg, #2193b0 0%, #6dd5ed 100%); /* Different color for assessor to distinguish from admin */
            color: white;
            padding: 15px 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .navbar h1 {
            font-size: 24px;
        }
        
        .navbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-avatar {
            width: 35px;
            height: 35px;
            background: white;
            color: #2193b0;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        
        .btn-logout {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 1px solid white;
            padding: 8px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s;
        }
        
        .btn-logout:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 30px;
        }
        
        .welcome-section {
            background: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        
        .stat-card h3 {
            color: #666;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 10px;
            text-transform: uppercase;
        }
        
        .stat-value {
            font-size: 36px;
            font-weight: bold;
            color: #2193b0;
        }
        
        .stat-card.success .stat-value { color: #4caf50; }
        .stat-card.warning .stat-value { color: #ff9800; }
        .stat-card.info .stat-value { color: #2196f3; }
        
        .search-bar {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .search-bar form {
            display: flex;
            gap: 10px;
        }
        
        .search-bar input {
            flex: 1;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .search-bar button {
            padding: 10px 25px;
            background: linear-gradient(135deg, #2193b0 0%, #6dd5ed 100%);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        
        .btn-clear {
            padding: 10px 25px;
            background: #9e9e9e;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
        }

        .table-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead { background: #f8f9fa; }
        th { padding: 15px; text-align: left; font-weight: 600; color: #333; border-bottom: 2px solid #e0e0e0; }
        td { padding: 15px; border-bottom: 1px solid #e0e0e0; color: #666; }
        tr:hover { background: #f8f9fa; }
        
        .badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-pending { background: #fff3e0; color: #e65100; }
        .badge-completed { background: #e8f5e9; color: #2e7d32; }
        
        .action-buttons { display: flex; gap: 10px; }
        
        .btn-action {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            text-decoration: none;
            color: white;
            font-weight: 500;
        }
        
        .btn-evaluate { background: #ff9800; }
        .btn-evaluate:hover { background: #f57c00; }
        .btn-view { background: #4caf50; }
        .btn-view:hover { background: #388e3c; }

        .alert {
            padding: 15px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .alert-success { background-color: #e8f5e9; border-left: 4px solid #4caf50; color: #2e7d32; }
        .alert-error { background-color: #fee; border-left: 4px solid #f44336; color: #c33; }

        .no-records { padding: 40px; text-align: center; color: #999; }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-content">
            <h1>Assessor Dashboard</h1>
            <div class="navbar-right">
                <div class="user-info">
                    <div class="user-avatar">
                        <?php echo strtoupper(substr(get_user_name(), 0, 1)); ?>
                    </div>
                    <span><?php echo htmlspecialchars(get_user_name()); ?></span>
                </div>
                <a href="logout.php" class="btn-logout">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <?php if ($msg = get_success_message()): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div>
        <?php endif; ?>
        
        <?php if ($msg = get_error_message()): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($msg); ?></div>
        <?php endif; ?>

        <div class="welcome-section">
            <h2>Welcome, <?php echo htmlspecialchars(get_user_name()); ?>!</h2>
            <p>Manage and evaluate your assigned internship students here.</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card info">
                <h3>Total Assigned Students</h3>
                <div class="stat-value"><?php echo $stats['total_assigned']; ?></div>
            </div>
            <div class="stat-card warning">
                <h3>Pending Assessments</h3>
                <div class="stat-value"><?php echo $stats['pending_assessments']; ?></div>
            </div>
            <div class="stat-card success">
                <h3>Completed Assessments</h3>
                <div class="stat-value"><?php echo $stats['completed_assessments']; ?></div>
            </div>
            <div class="stat-card">
                <h3>Average Given Score</h3>
                <div class="stat-value"><?php echo $stats['average_score']; ?></div>
            </div>
        </div>
        
        <div class="search-bar">
            <form method="GET">
                <input type="text" name="search" placeholder="Search assigned students by ID, Name, or Company..." 
                       value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Search</button>
                <?php if (!empty($search)): ?>
                    <a href="assessor_dashboard.php" class="btn-clear">Clear</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="table-container">
            <?php if (count($assigned_students) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Programme</th>
                            <th>Company</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Score</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($assigned_students as $student): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($student['student_id']); ?></strong></td>
                                <td><?php echo htmlspecialchars($student['student_name']); ?></td>
                                <td><?php echo htmlspecialchars($student['programme']); ?></td>
                                <td><?php echo htmlspecialchars($student['company_name']); ?></td>
                                <td>
                                    <?php 
                                    if ($student['internship_start_date'] && $student['internship_end_date']) {
                                        echo date('M d', strtotime($student['internship_start_date'])) . ' - ' . 
                                             date('M d, Y', strtotime($student['internship_end_date']));
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php if ($student['assessment_id']): ?>
                                        <span class="badge badge-completed">Assessed</span>
                                    <?php else: ?>
                                        <span class="badge badge-pending">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo $student['final_score'] ? number_format($student['final_score'], 2) : '-'; ?>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <?php if ($student['assessment_id']): ?>
                                            <a href="view_assessment.php?id=<?php echo $student['internship_id']; ?>" class="btn-action btn-view">View Result</a>
                                        <?php else: ?>
                                            <a href="evaluate_student.php?id=<?php echo $student['internship_id']; ?>" class="btn-action btn-evaluate">Evaluate</a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-records">
                    <?php if (!empty($search)): ?>
                        No assigned students found matching "<?php echo htmlspecialchars($search); ?>".
                    <?php else: ?>
                        You currently have no students assigned to you for assessment.
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>