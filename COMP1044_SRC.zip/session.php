<?php
/**
 * Session Management
 * Handles user sessions, authentication checks, and role-based access
 * COMP1044 Assignment
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
require_once 'db_connect.php';

/**
 * Check if user is logged in
 * @return bool - True if logged in, false otherwise
 */
function is_logged_in() {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

/**
 * Check if user is Admin
 * @return bool - True if admin, false otherwise
 */
function is_admin() {
    return is_logged_in() && $_SESSION['role'] === 'Admin';
}

/**
 * Check if user is Assessor
 * @return bool - True if assessor, false otherwise
 */
function is_assessor() {
    return is_logged_in() && $_SESSION['role'] === 'Assessor';
}

/**
 * Require login - redirect to login page if not logged in
 */
function require_login() {
    if (!is_logged_in()) {
        $_SESSION['error_message'] = "Please login to access this page.";
        header("Location: login.php");
        exit();
    }
}

/**
 * Require admin role - redirect if not admin
 */
function require_admin() {
    require_login();
    if (!is_admin()) {
        $_SESSION['error_message'] = "Access denied. Admin privileges required.";
        header("Location: " . get_dashboard_url());
        exit();
    }
}

/**
 * Require assessor role - redirect if not assessor
 */
function require_assessor() {
    require_login();
    if (!is_assessor()) {
        $_SESSION['error_message'] = "Access denied. Assessor privileges required.";
        header("Location: " . get_dashboard_url());
        exit();
    }
}

/**
 * Get appropriate dashboard URL based on user role
 * @return string - Dashboard URL
 */
function get_dashboard_url() {
    if (is_admin()) {
        return 'admin_dashboard.php';
    } elseif (is_assessor()) {
        return 'assessor_dashboard.php';
    }
    return 'login.php';
}

/**
 * Login user and create session
 * @param int $user_id - User ID
 * @param string $username - Username
 * @param string $role - User role (Admin/Assessor)
 * @param string $name - Full name
 */
function login_user($user_id, $username, $role, $name) {
    // Regenerate session ID to prevent session fixation
    session_regenerate_id(true);
    
    $_SESSION['user_id'] = $user_id;
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $role;
    $_SESSION['name'] = $name;
    $_SESSION['login_time'] = time();
    
    // Set session timeout (30 minutes of inactivity)
    $_SESSION['last_activity'] = time();
}

/**
 * Logout user and destroy session
 */
function logout_user() {
    // Unset all session variables
    $_SESSION = array();
    
    // Destroy the session cookie
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    
    // Destroy the session
    session_destroy();
    
    // Redirect to login page
    header("Location: login.php");
    exit();
}

/**
 * Check session timeout (30 minutes)
 * Logout user if session has expired
 */
function check_session_timeout() {
    if (is_logged_in()) {
        $timeout_duration = 1800; // 30 minutes in seconds
        
        if (isset($_SESSION['last_activity']) && 
            (time() - $_SESSION['last_activity']) > $timeout_duration) {
            logout_user();
        }
        
        // Update last activity time
        $_SESSION['last_activity'] = time();
    }
}

/**
 * Generate CSRF token
 * @return string - CSRF token
 */
function generate_csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 * @param string $token - Token to verify
 * @return bool - True if valid, false otherwise
 */
function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Get user display name
 * @return string - User's display name
 */
function get_user_name() {
    return isset($_SESSION['name']) ? $_SESSION['name'] : 'User';
}

/**
 * Get user role
 * @return string - User's role
 */
function get_user_role() {
    return isset($_SESSION['role']) ? $_SESSION['role'] : '';
}

/**
 * Set success message
 * @param string $message - Success message
 */
function set_success_message($message) {
    $_SESSION['success_message'] = $message;
}

/**
 * Set error message
 * @param string $message - Error message
 */
function set_error_message($message) {
    $_SESSION['error_message'] = $message;
}

/**
 * Get and clear success message
 * @return string - Success message or empty string
 */
function get_success_message() {
    if (isset($_SESSION['success_message'])) {
        $message = $_SESSION['success_message'];
        unset($_SESSION['success_message']);
        return $message;
    }
    return '';
}

/**
 * Get and clear error message
 * @return string - Error message or empty string
 */
function get_error_message() {
    if (isset($_SESSION['error_message'])) {
        $message = $_SESSION['error_message'];
        unset($_SESSION['error_message']);
        return $message;
    }
    return '';
}

// Check session timeout on every page load
check_session_timeout();
?>
