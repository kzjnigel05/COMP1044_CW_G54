<?php
/**
 * View Assessment - Result Display
 * COMP1044 Assignment
 */

require_once 'session.php';
require_once 'db_connect.php';

require_login();

$internship_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$current_user_id = $_SESSION['user_id'];
$is_admin = is_admin();

if ($internship_id === 0) {
    set_error_message("Invalid internship ID.");
    header("Location: " . (is_admin() ? 'admin_dashboard.php' : 'assessor_dashboard.php'));
    exit();
}

// Join assessments with internships and students for full context
$sql = "SELECT a.*, s.student_id, s.student_name, s.programme, i.company_name, i.assessor_id
        FROM assessments a
        JOIN internships i ON a.internship_id = i.internship_id
        JOIN students s ON i.student_id = s.id
        WHERE a.internship_id = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $internship_id);
mysqli_stmt_execute($stmt);
$data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Security: If record exists but user is not Admin and not the assigned Assessor, block access
if (!$data || (!$is_admin && $data['assessor_id'] != $current_user_id)) {
    set_error_message("Assessment result not found or access denied.");
    header("Location: " . ($is_admin ? 'admin_dashboard.php' : 'assessor_dashboard.php'));
    exit();
}

// Weights as defined in your technical notes for display
$weights = [
    'undertaking_tasks' => 0.10, 'health_safety' => 0.10, 'connectivity_knowledge' => 0.10,
    'report_presentation' => 0.15, 'clarity_language' => 0.10, 'lifelong_learning' => 0.15,
    'project_management' => 0.15, 'time_management' => 0.15
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Assessment Result</title>
    <style>
        body { font-family: sans-serif; background: #f4f4f4; padding: 20px; }
        .result-card { max-width: 800px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .score-display { font-size: 2em; font-weight: bold; color: #2c3e50; text-align: right; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px; border-bottom: 1px solid #ddd; text-align: left; }
        th { background: #f8f9fa; }
        .feedback-box { background: #fdfdfd; border-left: 4px solid #3498db; padding: 15px; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="result-card">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h1>Internship Assessment</h1>
                <p><strong>Student:</strong> <?php echo htmlspecialchars($data['student_name']); ?> (<?php echo htmlspecialchars($data['student_id']); ?>)</p>
                <p><strong>Programme:</strong> <?php echo htmlspecialchars($data['programme']); ?></p>
                <p><strong>Company:</strong> <?php echo htmlspecialchars($data['company_name']); ?></p>
            </div>
            <div class="score-display">
                <small>FINAL SCORE</small><br>
                <?php echo number_format($data['final_score'], 2); ?>%
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Component</th>
                    <th>Weight</th>
                    <th>Score</th>
                    <th>Weighted Contribution</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($weights as $column => $weight): ?>
                <tr>
                    <td><?php echo ucwords(str_replace('_', ' ', $column)); ?></td>
                    <td><?php echo ($weight * 100); ?>%</td>
                    <td><?php echo number_format($data[$column], 2); ?> / 100</td>
                    <td><?php echo number_format($data[$column] * $weight, 2); ?>%</td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="feedback-box">
            <h3>Assessor General Feedback</h3>
            <p><?php echo nl2br(htmlspecialchars($data['general_feedback'] ?? 'No feedback provided.')); ?></p>
        </div>

        <div style="margin-top: 30px;">
            <button onclick="window.print()">Print Report</button>
            <a href="<?php echo $is_admin ? 'admin_dashboard.php' : 'assessor_dashboard.php'; ?>">Back to Dashboard</a>
        </div>
    </div>
</body>
</html>