# Internship Result Management System
## COMP1044 Assignment - Security & Admin Module

### Overview
This is a web-based Internship Result Management System that allows university administrators and assessors to manage student internship records and assessments efficiently.

### Primary Focus Areas (Member 2 Deliverables)
1. **Security & Login System** - Secure authentication with role-based access control
2. **Admin Dashboard** - Comprehensive overview with system statistics
3. **User Management** - CRUD operations for Students and Assessors
4. **Database Connectivity** - Centralized database connection and utility functions

---

## System Requirements

### Server Requirements
- PHP 7.4 or higher
- MySQL 5.7 or higher / MariaDB 10.2 or higher
- Apache/Nginx web server
- PDO PHP Extension
- mysqli PHP Extension

### Recommended Development Environment
- XAMPP (Windows/Mac/Linux)
- WAMP (Windows)
- MAMP (Mac)
- LAMP (Linux)

---

## Installation Instructions

### Step 1: Database Setup

1. Start your MySQL server (via XAMPP/WAMP control panel)

2. Import the database:
   ```sql
   # Method 1: Using command line
   mysql -u root -p < COMP1044_Database.sql
   
   # Method 2: Using phpMyAdmin
   - Open phpMyAdmin (http://localhost/phpmyadmin)
   - Click "Import" tab
   - Choose COMP1044_Database.sql file
   - Click "Go"
   ```

3. The database will be created with:
   - Database name: `internship_management`
   - Default admin credentials:
     - Username: `admin`
     - Password: `admin123`
   - Sample assessors and students for testing

### Step 2: Configure Database Connection

1. Open `db_connect.php`

2. Update database credentials if needed:
   ```php
   define('DB_SERVER', 'localhost');     // Your MySQL server
   define('DB_USERNAME', 'root');        // Your MySQL username
   define('DB_PASSWORD', '');            // Your MySQL password
   define('DB_NAME', 'internship_management');
   ```

### Step 3: Deploy Files

1. Copy all PHP files to your web server's root directory:
   - For XAMPP: `C:\xampp\htdocs\internship_system\`
   - For WAMP: `C:\wamp64\www\internship_system\`
   - For MAMP: `/Applications/MAMP/htdocs/internship_system/`

2. Ensure proper file permissions (Linux/Mac):
   ```bash
   chmod 755 *.php
   ```

### Step 4: Access the System

1. Start Apache and MySQL services

2. Open your web browser and navigate to:
   ```
   http://localhost/internship_system/login.php
   ```

3. Login with default credentials:
   - **Admin Account:**
     - Username: `admin`
     - Password: `admin123`
   
   - **Sample Assessor Accounts:**
     - Username: `assessor1`, `assessor2`, or `assessor3`
     - Password: `admin123` (for all)

---

## File Structure

```
internship_system/
├── db_connect.php          # Database connection & utility functions
├── session.php             # Session management & authentication
├── login.php               # User login page
├── logout.php              # Logout handler
├── admin_dashboard.php     # Admin dashboard with statistics
├── manage_students.php     # Student CRUD operations
├── manage_assessors.php    # Assessor CRUD operations
└── COMP1044_Database.sql   # Database schema & sample data
```

---

## Features Implemented

### 1. Security & Authentication (`login.php` + `session.php`)
- ✅ Secure password hashing (bcrypt)
- ✅ Session management with timeout (30 minutes)
- ✅ Role-based access control (Admin/Assessor)
- ✅ CSRF protection
- ✅ SQL injection prevention
- ✅ XSS protection
- ✅ Login attempt tracking
- ✅ Session fixation prevention
- ✅ Password visibility toggle
- ✅ Input validation

### 2. Admin Dashboard (`admin_dashboard.php`)
- ✅ Real-time system statistics:
  - Total students count
  - Total assessors count
  - Total internships
  - Pending assessments
  - Completed assessments
  - Average assessment score
- ✅ Recent activity feed
- ✅ Quick action buttons
- ✅ Responsive design
- ✅ User profile display
- ✅ Success/Error message alerts

### 3. Student Management (`manage_students.php`)
- ✅ Add new students
- ✅ Edit student information
- ✅ Delete students (soft delete with validation)
- ✅ Search students by ID, name, or programme
- ✅ Modal-based forms
- ✅ Form validation (client & server-side)
- ✅ Duplicate prevention
- ✅ Foreign key constraint checking
- ✅ Activity logging

### 4. Assessor Management (`manage_assessors.php`)
- ✅ Add new assessors
- ✅ Edit assessor accounts
- ✅ Delete assessors (with validation)
- ✅ Password management
- ✅ View assigned student count
- ✅ Search functionality
- ✅ Username uniqueness validation
- ✅ Email validation
- ✅ Activity logging

### 5. Database Connectivity (`db_connect.php`)
- ✅ Centralized connection management
- ✅ UTF-8 character encoding
- ✅ Input sanitization function
- ✅ Email validation function
- ✅ Activity logging function
- ✅ Error handling
- ✅ Connection testing

---

## Database Schema

### Tables Created

1. **users** - Stores admin and assessor accounts
   - Primary Key: `user_id`
   - Unique: `username`
   - Fields: username, password (hashed), full_name, email, role, is_active

2. **students** - Stores student information
   - Primary Key: `id`
   - Unique: `student_id`
   - Fields: student_id, student_name, programme, email, phone, is_active

3. **internships** - Links students with assessors and companies
   - Primary Key: `internship_id`
   - Foreign Keys: `student_id`, `assessor_id`
   - Fields: company_name, start_date, end_date

4. **assessments** - Stores internship evaluation scores
   - Primary Key: `assessment_id`
   - Foreign Key: `internship_id`, `assessed_by`
   - Auto-calculates final_score based on weightages
   - 8 assessment components with comments
   - Weightages: 10%, 10%, 10%, 15%, 10%, 15%, 15%, 15%

5. **activity_logs** - Tracks system activities
   - Logs all major operations for audit trail

6. **login_attempts** - Security tracking
   - Records failed/successful login attempts

---

## Security Features

### Password Security
- Passwords hashed using bcrypt (`password_hash()`)
- Minimum 6 character requirement
- Never stored in plain text

### SQL Injection Prevention
- All queries use prepared statements
- Input sanitization with `mysqli_real_escape_string()`
- Parameterized queries throughout

### XSS Prevention
- All output escaped with `htmlspecialchars()`
- Input sanitization before display

### Session Security
- Session ID regeneration on login
- 30-minute inactivity timeout
- CSRF token validation
- Secure session configuration

### Access Control
- Role-based authentication (Admin/Assessor)
- Function-based permission checks
- Protected routes with `require_admin()` / `require_assessor()`
- Automatic redirect for unauthorized access

---

## Testing Credentials

### Admin Account
```
Username: admin
Password: admin123
```

### Assessor Accounts
```
Username: assessor1
Password: admin123

Username: assessor2
Password: admin123

Username: assessor3
Password: admin123
```

### Sample Students
The database includes 8 sample students with IDs:
- CS2021001, CS2021002, CS2021003, CS2021004
- SE2021001, SE2021002
- IT2021001, IT2021002

---

## Usage Guide

### Admin Workflow

1. **Login**
   - Navigate to `login.php`
   - Enter admin credentials
   - System redirects to admin dashboard

2. **Manage Students**
   - Click "Manage Students" from dashboard
   - Add new students using "Add New Student" button
   - Edit existing students by clicking "Edit"
   - Delete students by clicking "Delete" (with confirmation)
   - Search for students using the search bar

3. **Manage Assessors**
   - Click "Manage Assessors" from dashboard
   - Add new assessor accounts
   - Edit assessor information
   - View assigned student count
   - Delete assessors (validates for assigned students)

4. **View Statistics**
   - Dashboard shows real-time statistics
   - Monitor pending and completed assessments
   - Track average scores
   - Review recent system activity

---

## Code Structure & Best Practices

### File Organization
- Separate files for each major function
- Modular code with reusable functions
- Consistent naming conventions

### Database Practices
- Prepared statements for all queries
- Foreign key constraints for referential integrity
- Indexes on frequently queried columns
- Soft deletes (is_active flag)
- Activity logging for audit trail

### Security Practices
- Input validation (client and server-side)
- Output encoding
- Parameterized queries
- Session management
- Error handling without information disclosure

### UI/UX Features
- Responsive design
- Modal forms for better UX
- Confirmation dialogs for destructive actions
- Success/error message feedback
- Search functionality
- Clean, professional interface

---

## Troubleshooting

### Common Issues

**1. Cannot connect to database**
```
Solution: 
- Check if MySQL is running
- Verify credentials in db_connect.php
- Ensure database exists
```

**2. Login not working**
```
Solution:
- Check if users table has admin account
- Verify password is 'admin123'
- Check session configuration in php.ini
```

**3. Permission denied errors**
```
Solution:
- Check file permissions (755 for PHP files)
- Ensure web server has read access
```

**4. Session timeout too fast**
```
Solution:
- Modify timeout in session.php (line: $timeout_duration)
- Default is 1800 seconds (30 minutes)
```

---

## Future Enhancements (Not in Current Scope)

Member 2's deliverables are complete. Future work by other members:
- Internship management interface
- Assessment entry forms (Member 3)
- Result viewing and reporting
- Email notifications
- Export functionality
- Advanced analytics

---

## Technical Notes

### Assessment Score Calculation
The final score is auto-calculated using stored computed column:
```sql
final_score = (undertaking_tasks * 0.10) +
              (health_safety * 0.10) +
              (connectivity_knowledge * 0.10) +
              (report_presentation * 0.15) +
              (clarity_language * 0.10) +
              (lifelong_learning * 0.15) +
              (project_management * 0.15) +
              (time_management * 0.15)
```

### Session Configuration
- Timeout: 30 minutes
- Secure: Regenerates ID on login
- HTTP Only: Prevents JavaScript access
- Activity tracking: Updates on each request

---

## Support & Contact

For issues or questions regarding this implementation:
- Check the troubleshooting section
- Review code comments
- Verify database configuration
- Test with sample credentials

---

## License & Academic Integrity

This code is submitted as part of COMP1044 coursework.
- Use for educational purposes only
- Do not copy without proper attribution
- Follow university academic integrity policies

---

**Developed by: [Your Name]**
**Course: COMP1044 - Database and Interfaces**
**Assignment: Internship Result Management System**
**Date: April 2026**
